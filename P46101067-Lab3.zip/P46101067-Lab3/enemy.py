import pygame
import math
import os
from settings import PATH_A,PATH_B

pygame.init()
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))

count=0
class Enemy:
    def __init__(self):
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        global count
        #若爲奇數次，就從左邊開始
        if (count%2==0):
            self.path = PATH_A
        #若為偶數次，便從右邊開始
        else:  
            self.path=PATH_B
        self.stride = 1
        #定義第一個位置為path[0]
        self.x, self.y = self.path[0]
        self.move_count=0
        self.position=0
        

    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)

    def draw_health_bar(self, win):
        #將綠血條的長度設定成自身寬度乘上血量百分比，並將血條固定在人物上方
        pygame.draw.rect(win, (0,255,0), [(self.x - self.width // 2), (self.y - self.height // 2),\
                                          (self.width*self.health/self.max_health), 5])
        #將紅血條的長度設定成自身寬度乘上(1-血量百分比)，也就是剩餘的血量，並將血條固定在人物上方
        pygame.draw.rect(win, (255,0,0), [(self.x - self.width // 2)+(self.width*self.health/self.max_health),
                                        (self.y - self.height // 2),(self.width*(1-self.health/self.max_health)), 5])

    def move(self):
        #設定最大值，若移動到最後一個點之後將不再繼續
        if(self.position==len(self.path)-1):
            pass
        #當還沒走到最後一個點時，則繼續往後
        elif(self.position<len(self.path)-1):
            stride = 1
            #目前座標
            ax,ay=self.path[self.position] 
            #下一個點的座標
            bx,by=self.path[self.position+1]
            distance_A_B = math.sqrt((ax - bx)**2 + (ay - by)**2)#AB兩點間的距離
            max_count = int(distance_A_B / stride)  # total footsteps that needed from A to B
            unit_vector_x = (bx - ax) / distance_A_B#X方向的單位向量
            unit_vector_y = (by - ay) / distance_A_B#Y方向的單位向量
            delta_x = unit_vector_x * stride#每一步X方向的移動量
            delta_y = unit_vector_y * stride#每一步的Y方向移動量
             # update the coordinate and the counter
            self.x += delta_x
            self.y += delta_y
            #記錄在移動中所走的步數
            self.move_count += 1
            #2當已走的步數達到目標步數，表示已經達到目標點，則將目標往下一個點移動
            if(self.move_count==max_count):
                self.position+=1 
                #步數歸零
                self.move_count=0


class EnemyGroup:
    def __init__(self):
        self.campaign_count = 0
        self.campaign_max_count = 120   # (unit: frame)
        self.reserved_members = []
        self.expedition = []  # don't change this line until you do the EX.3 
        self.enemy_number=0
        self.frame=0
        self.wave=0

    def campaign(self):

        # Hint: self.expedition.append(self.reserved_members.pop())
        #若self.campaign_count等於self.campaign_max_count且 self.is_empty()不是空的
        if self.campaign_count==self.campaign_max_count and self.is_empty()==False :
            #則將self.reserved_members.pop()清空並加到self.expedition中
            self.expedition.append(self.reserved_members.pop())
            self.campaign_count=0
        #如果self.reserved_members 是空的，則將self.campaign_count設定成0
        elif self.is_empty()==True: 
            self.campaign_count=0
         #如果self.reserved_members 不是空的，則將self.campaign_count +1
        else:
            self.campaign_count+=1


    def generate(self, num):
        #傳入num個Enemy()到self.reserved_members中
        for i in range(num):  
            self.reserved_members.append(Enemy())
        global count  
        count+=1

    def get(self):
        """
        Get the enemy list
        """
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)





